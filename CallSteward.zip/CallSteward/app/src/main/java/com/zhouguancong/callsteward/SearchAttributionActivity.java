package com.zhouguancong.callsteward;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SearchAttributionActivity extends Activity {
    private EditText phone_number;
    private TextView tv_province;
    private TextView tv_city;
    private TextView tv_company;
    private String phone;
    private static String province;
    private static String city;
    private static String company;

    // This is my app key, please don't let others use it except you
    public static final String APPKEY = "56d89465a6cb9ca44014dbd6833d6691";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_attribution);
        phone_number = (EditText) findViewById(R.id.phone_number);
        tv_province = (TextView) findViewById(R.id.tv_province);
        tv_city = (TextView) findViewById(R.id.tv_city);
        tv_company = (TextView) findViewById(R.id.tv_company);
    }

    public void query(View v){
        phone = phone_number.getText().toString().trim();
        if (!TextUtils.isEmpty(phone)) {
            new Thread(){
                public void run() {
                    handler.obtainMessage(0).sendToTarget();
                    query_attribution(phone);
                    handler.obtainMessage(1).sendToTarget();
                };
            }.start();
        }else {
            Toast.makeText(SearchAttributionActivity.this, "The input can't be null", Toast.LENGTH_SHORT).show();
        }
    }

    Handler handler = new Handler(){
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case 0:
                    Toast.makeText(SearchAttributionActivity.this, "Execute query, please wait", Toast.LENGTH_SHORT).show();
                    break;

                case 1: {
                    tv_province.setText("省份:\t\t\t" + province);
                    tv_city.setText("城市:\t\t\t" + city);
                    tv_company.setText("服务商:\t\t" + company);
                }
                break;
                default:
                    break;
            }
        };
    };

    public static void query_attribution(String phone){
        String result = null;
        String url ="http://apis.juhe.cn/mobile/get";
        Map para_input = new HashMap();
        para_input.put("phone", phone);
        para_input.put("key", APPKEY);
        para_input.put("dtype", "");

        try {
            result = get_attribution(url, para_input, "GET");
            JSONObject object = new JSONObject(result);
            JSONObject ob = new JSONObject(object.get("result").toString()+"");
            province = ob.getString("province");
            city = ob.getString("city");
            company = ob.getString("company");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String get_attribution(String url_s, Map para_input,String method) throws Exception {
        HttpURLConnection conn = null;
        BufferedReader reader = null;
        String attribution = null;
        try {
            StringBuffer temp = new StringBuffer();
            if((method==null) || (method.equals("GET"))){
                url_s = url_s + "?" + url_str(para_input);
            }
            URL url = new URL(url_s);
            conn = (HttpURLConnection) url.openConnection();
            if((method==null) || (method.equals("GET"))){
                conn.setRequestMethod("GET");
            } else {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
            }

            conn.setUseCaches(false);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setInstanceFollowRedirects(false);
            conn.connect();
            if((para_input!= null) && (method.equals("POST"))) {
                try {
                    DataOutputStream out = new DataOutputStream(conn.getOutputStream());
                    out.writeBytes(url_str(para_input));
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            InputStream is = conn.getInputStream();
            reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String strRead = null;
            while ((strRead = reader.readLine()) != null) {
                temp.append(strRead);
            }
            attribution = temp.toString();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(reader != null) {
                reader.close();
            }
            if(conn != null) {
                conn.disconnect();
            }
        }
        return attribution;
    }

    public static String url_str(Map<String,String> data) {
        StringBuilder temp = new StringBuilder();
        for (Map.Entry i : data.entrySet()) {
            try {
                temp.append(i.getKey()).append("=").append(URLEncoder.encode(i.getValue()+"","UTF-8")).append("&");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return temp.toString();
    }
}