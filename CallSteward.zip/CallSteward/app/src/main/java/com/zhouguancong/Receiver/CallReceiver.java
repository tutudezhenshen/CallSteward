package com.zhouguancong.Receiver;

/**
 * Created by cong on 2017/11/24.
 */

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;

import com.zhouguancong.Services.chkIncomingPhoneNumService;
import com.zhouguancong.callsteward.R;

import static android.content.Context.WINDOW_SERVICE;

public class CallReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        //Log.w("intent " , intent.getAction().toString());

        String stateStr = intent.getExtras().getString(TelephonyManager.EXTRA_STATE);
        String number = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);

        if(stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)){
            System.out.println("------->" + number);
            intent.setClass(context, chkIncomingPhoneNumService.class);
            intent.putExtra("phoneNum", number);
            context.startService(intent);
        }
    }
}
