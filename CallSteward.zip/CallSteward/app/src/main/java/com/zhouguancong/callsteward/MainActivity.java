package com.zhouguancong.callsteward;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btn_ViewCallLog = (Button)findViewById(R.id.btn_ViewCallLog);
        final Button btn_SearchAttribution = (Button)findViewById(R.id.btn_SearchAttribution);
        btn_ViewCallLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CallLogActivity.class);
                startActivity(intent);
            }
        });

        btn_SearchAttribution.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), SearchAttributionActivity.class);
                startActivity(intent);
            }
        });
    }
}
