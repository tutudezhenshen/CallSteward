package com.zhouguancong.Services;

import android.app.AlertDialog;
import android.app.IntentService;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.zhouguancong.callsteward.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by cong on 2017/11/25.
 */

public class chkIncomingPhoneNumService extends Service {
    boolean existFlag = false;
    WindowManager wm;
    LayoutInflater inflate;
    View phoneView;
    ImageButton btnclose;
    ImageView alert;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String incomingPhoneNum = intent.getStringExtra("phoneNum");
        incomingPhoneNum = StringFilter(incomingPhoneNum);
        System.out.println("incoming call: " + incomingPhoneNum);


        Cursor cur = getContacts();
        for(cur.moveToFirst();!cur.isAfterLast();cur.moveToNext())
        {
            int idColumn = cur.getColumnIndex(ContactsContract.Contacts._ID);
            Long idNum = Long.parseLong(cur.getString(idColumn));

            Cursor curNum = getPhones(idNum);
            for(curNum.moveToFirst();!curNum.isAfterLast();curNum.moveToNext()){
                int numberColumn = curNum.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                String number = curNum.getString(numberColumn);
                number = StringFilter(number);
                System.out.println(number);
                if (number.equals(incomingPhoneNum)) {
                    existFlag = true;
                }
            }
        }

        if (existFlag == false) {
            inflate=LayoutInflater.from(this.getApplicationContext());
            wm=(WindowManager)getSystemService(WINDOW_SERVICE);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams();
            params.type = WindowManager.LayoutParams.TYPE_PHONE;
//            params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL ;
            params.width =WindowManager.LayoutParams.WRAP_CONTENT;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.format = PixelFormat.RGBA_8888;
            phoneView=inflate.inflate(R.layout.phone_alert1,null);
            alert=phoneView.findViewById(R.id.alertpic);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final Bitmap bitmap=getPicture("http://i.cs.hku.hk/~twchim/police/warning.jpg");
                    alert.post(new Runnable() {
                        @Override
                        public void run() {
                            alert.setImageBitmap(bitmap);
                        }
                    });
                }
            }).start();
            wm.addView(phoneView, params);

            phoneView.setFocusableInTouchMode(true);
            phoneView.setFocusable(true);
            phoneView.setClickable(true);
            btnclose=phoneView.findViewById(R.id.close);
            btnclose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    wm.removeView(phoneView);
                }
            });
        }
        existFlag=false;
        return super.onStartCommand(intent, flags, startId);
    }


    private Cursor getContacts() {
        Uri contactsUri = ContactsContract.Contacts.CONTENT_URI;
        String[] columns = {
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME };
        String sortOrder = ContactsContract.Contacts.DISPLAY_NAME;

        // getContentResolver() can be used in an activity
        return getContentResolver().query(
                contactsUri, columns, null, null, sortOrder);
    }


    private Cursor getPhones(long id) {
        Uri phoneUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] columns = {
                ContactsContract.CommonDataKinds.Phone.TYPE,
                ContactsContract.CommonDataKinds.Phone.NUMBER };
        String selection = ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ? ";
        String[] selectionArgs = {String.valueOf(id)};
        return getContentResolver().query(phoneUri, columns, selection, selectionArgs, null);
    }

    public Bitmap getPicture(String path){
        Bitmap bm=null;
        try{
            URL url=new URL(path);
            URLConnection connection=url.openConnection();
            connection.connect();
            InputStream inputStream=connection.getInputStream();
            bm= BitmapFactory.decodeStream(inputStream);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  bm;
    }

    public String StringFilter(String str){
        // 只允许字母和数字
        String regEx = "[^0-9]";
        // 清除掉所有特殊字符
        //String regEx="[`~!@#$%^&*()+=|{}':;',//[//].<>/?~！@#￥%……&*（）—+|{}【】‘；：”“’。，、？]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        return m.replaceAll("").trim();
    }
}
