package com.zhouguancong.callsteward;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.Manifest;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CallLog;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.support.v7.app.AppCompatActivity;

public class CallLogActivity extends AppCompatActivity {

    private ListView LvItem;
    private List<Map<String, Object>> call_log;
    private SimpleAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_log);
        LvItem = (ListView)findViewById(R.id.lv_item);
        System.out.println(LvItem);
        call_log = get_call_log();
        adapter = new SimpleAdapter(this, call_log, R.layout.simple_calllog_item,
                new String[] {"name", "type", "number", "date", "duration"},
                new int[] {R.id.tv_name, R.id.tv_type, R.id.tv_number, R.id.tv_date, R.id.tv_duration});
        LvItem.setAdapter(adapter);
    }

    private List<Map<String, Object>> get_call_log() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALL_LOG}, 1);
        }

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        ContentResolver resolver = getContentResolver();
        Cursor cursor = resolver.query(CallLog.Calls.CONTENT_URI,
                new String[] {CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.TYPE},
                null, null, CallLog.Calls.DEFAULT_SORT_ORDER);

        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndex(CallLog.Calls.CACHED_NAME));
            String number = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
            long date_temp = cursor.getLong(cursor.getColumnIndex(CallLog.Calls.DATE));
            String date = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date(date_temp));
            int duration = cursor.getInt(cursor.getColumnIndex(CallLog.Calls.DURATION));
            int type = cursor.getInt(cursor.getColumnIndex(CallLog.Calls.TYPE));
            String type_str = "";

            switch (type) {
                case CallLog.Calls.INCOMING_TYPE:
                    type_str = "Call In";
                    break;
                case CallLog.Calls.OUTGOING_TYPE:
                    type_str = "Call Out";
                    break;
                case CallLog.Calls.MISSED_TYPE:
                    type_str = "Missed";
                    break;
                default:
                    break;
            }

            Map<String, Object> map = new HashMap<String, Object>();
            map.put("name", (name == null) ? "Unknown Contact" : name);
            map.put("number", number);
            map.put("date", date);
            map.put("duration", ((duration/60) + "min " + (duration-duration/60*60) + "s"));
            map.put("type", type_str);
            list.add(map);
        }
        return list;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        return ;
    }
}
